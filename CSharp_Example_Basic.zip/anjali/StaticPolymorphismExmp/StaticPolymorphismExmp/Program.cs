﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticPolymorphismExmp
{
    public class Program
    {
        public class print
        {
            public void display(string name)
            {
                Console.WriteLine("your name is :"+name );
            }
            public void display(int age,double marks)
            {
                Console.WriteLine("your age is :"+age);
                Console.WriteLine("your marks is :"+marks );
            }
        }
        static void Main(string[] args)
        {
            print p1 = new print();
            p1.display("jon");
            p1.display(25,72.35);
            Console.ReadKey();
        }
    }
}
