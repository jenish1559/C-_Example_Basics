﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack stack1 = new Stack();
            stack1.Push("hello");
            stack1.Push(1);
            stack1.Push(2.2);
            stack1.Push(3);
            stack1.Push(4.3);
            stack1.Push(5);
            stack1.Push(true);

            foreach (var st1 in stack1 )
            {
                Console.WriteLine("the stack value is :"+st1);
            }
            Console.WriteLine("\n");

            Console.WriteLine("the stack peek value is :"+stack1 .Peek());
            Console.WriteLine("\n");

            Console.WriteLine("the total stack value is :"+stack1.Count);
            Console.WriteLine("\n");

            Console.WriteLine("avalible contain value :"+stack1.Contains(3));
            Console.WriteLine("avalible contain value :"+stack1.Contains(10));

            Console.WriteLine("\n");

            Stack stack2 = new Stack();
            stack2.Push(1);
            stack2.Push(2);
            stack2.Push(3);
            stack2.Push(4);
            stack2.Push(5);
            Console.WriteLine("\n");
          
            Console.WriteLine(stack2.Pop());
           
            Console.WriteLine("\n");
            Console.WriteLine("Number of elements in Stack: "+stack2.Count);

           // while (stack2.Count > 2)
            //{ 
            //    Console.WriteLine(stack2.Pop());
           // }
            //    Console.Write("Number of elements in Stack: " + stack2.Count);

              //  Console.WriteLine("\n");

               // Console.WriteLine(stack2 .Count );
            
            Console.ReadKey();
        }

    }
}
