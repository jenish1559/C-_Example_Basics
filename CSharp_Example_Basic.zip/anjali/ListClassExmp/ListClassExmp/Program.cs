﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClassExmp
{

    public class Program
    {
        static void Main(string[] args)
        {
            List<Test> l1 = new List<Test>();

            l1.Add(new Test() { id = 1, name = "anjali" });
            l1.Add(new Test() { id = 2, name = "arpita" });
            l1.Add(new Test() { id = 3, name = "taksh" });
            l1.Add(new Test() { id = 4, name = "harsh" });
            l1.ForEach(a => Console.WriteLine(a.id));
            l1.ForEach(b => Console.WriteLine(b.name));

            Console.WriteLine(l1.Count);
            Console.ReadKey();
        }
    }
}
