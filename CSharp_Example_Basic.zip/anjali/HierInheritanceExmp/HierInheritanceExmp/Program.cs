﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HierInheritanceExmp
{
    public class Animal
    {
        public void eat()
        {
            Console.WriteLine("Eating...");
        }
    }
    public class Dog : Animal
    {
        public void bark()
        {
            Console.WriteLine("Barking...");
        }
    }
    public class Babydog : Animal 
    {
       public void weep()
        {
            Console.WriteLine("weeping...");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Dog d1 = new Dog();
            Babydog b1 = new Babydog();
            d1.eat();
            d1.bark();
            Console.WriteLine("\n");
            b1.eat();
            b1.weep();
            Console.ReadKey();

        }
    }
}
