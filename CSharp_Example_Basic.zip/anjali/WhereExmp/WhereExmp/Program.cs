﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhereExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers= {10,20,30,40,50 };

            var result = from number in numbers where number <= 30 select number;

            foreach(int val in result )
            {
                Console.WriteLine("the values are :"+val);
            }

            Console.WriteLine("\n");

            IList list1 = new ArrayList();
            list1.Add(0);
            list1.Add("abc");
            list1.Add("x");
            list1.Add(2);
            list1.Add("yz");
            list1.Add(1);

            var res = from s1 in list1.OfType<string>() select s1;

            foreach (var val1 in res)
            {
                Console.WriteLine("the values are :" + val1);
            }

            Console.ReadKey();
        }
    }
}
