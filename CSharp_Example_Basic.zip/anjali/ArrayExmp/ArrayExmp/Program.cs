﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            string [] sName =new string [5];

            sName[0] = "c";
            sName[1] = "c++";
            sName[2] = "c#";
            sName[3] = "asp.net";
            sName[4] = "java";
         
            foreach (string n in sName )
            {
                Console.WriteLine("the sub name is :\t" +n );
            }
            Console.ReadKey();
        }

    }
}
