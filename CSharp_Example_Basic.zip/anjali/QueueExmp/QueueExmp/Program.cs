﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue que1 = new Queue();
            que1.Enqueue(1);
            que1.Enqueue("hello");
            que1.Enqueue(2);
            que1.Enqueue(3.5);
            que1.Enqueue(false);
            que1.Enqueue(4);
            foreach (var q in que1 )
            {
                Console.WriteLine("the queue values is :"+q);
            }
            Console.WriteLine("\n");
            Console.WriteLine("the total queue value is :"+que1 .Count );
            
            Console.WriteLine("\n");

            Console.WriteLine(que1 .Dequeue());
            Console.WriteLine("\n");
            Console.WriteLine("the total queue value is :" + que1.Count);

            Console.ReadKey();
        }
    }
}
