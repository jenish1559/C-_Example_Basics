﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace function
{
  public  class Program
    {
        
    public void show()
      {
          Console.WriteLine("the value is :");
      }
     
            
        static void Main(string[] args)
        {
            Program p1 = new Program();
            p1.show();
            Console.ReadKey();
        }
    }
}
