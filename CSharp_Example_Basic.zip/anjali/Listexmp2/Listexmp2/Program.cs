﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listexmp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n");

            List<String> list1 = new List<String>();
          
            String input1 = Console.ReadLine();

            list1.Add(input1);

           String input2 = Console.ReadLine();

            list1.Add(input2);
           // list1.Add(Console.ReadLine());
            //list1.Add(Console.ReadLine ());
            //list1.Add(Console.ReadLine());

            Console.WriteLine("\n");
            foreach (var a in list1)
            {
                Console.WriteLine(a);
            }
            Console.ReadKey();
        }
    }
}
