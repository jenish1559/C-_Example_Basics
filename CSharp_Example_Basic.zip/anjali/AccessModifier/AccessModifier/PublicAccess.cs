﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModifier
{
    
    public class PublicAccess
    {
        public int id ;
      private  string name="anjali";
        public void pub_access()
        {
            id =10 ; 
        }

        public void priv_access(string fname)
        {
            name = fname ;
        }

 
       
    }
    private class a
    {
        public a()
        {
            Console.WriteLine("test");
       
    }
    }
    public class b
    {
        
        

    }
}
