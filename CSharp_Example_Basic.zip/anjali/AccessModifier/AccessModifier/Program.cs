﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModifier
{
  public  class Program
    {
        static void Main(string[] args)
        {
            PublicAccess pm = new PublicAccess();

            Console.WriteLine("the id is :" + pm.id);
            Console.WriteLine("the name is :"+pm.name);

            a b1 = new a();
            Console.ReadKey();
        }
    }
}
