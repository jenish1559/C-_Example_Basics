﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    public class Program
    {
        static void Main(string[] args)
        {
            emp id1 = new emp();
            emp id2 = new emp(6);

            Console.WriteLine("the defult con value is : " +id1.id);
            Console.WriteLine("the defult con value is : " + id2.id);
            Console.ReadKey();
        }
    }
}
