﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    public class emp
    {
        public int id;
        public emp()
        {
            id = 0;
        }

        public emp(int i)
        {
           id = i;
        }
    }
}
