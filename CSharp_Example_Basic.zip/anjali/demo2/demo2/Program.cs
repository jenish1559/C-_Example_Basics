﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo2
{
   public class Program
    {

        static void Main(string[] args)
        {
            int a = 15;
            int b = 10;
            int c;
            Boolean d = true;
            Boolean e =false ;

            c = a + b; //arithmetic
            Console.WriteLine("the value is:"+c );

            c = a--; //arithmetic
            Console.WriteLine("the value is:" + c);

            c += a;  //assignment
            Console.WriteLine("the value is:"+c);

            c %= b; //assignment
            Console.WriteLine("the value is:" + c);

            c <<= 1; //assignment
            Console.WriteLine("the value is:" + c);

            c = a & b; //bitwise
            Console.WriteLine("the value is :" + c);

            c = a ^ b; //bitwise
            Console.WriteLine("the value is :" + c);

            c = ~a;  //bitwise
            Console.WriteLine("the value is :" + c);

            if (a >= b) //relational
            {
                Console.WriteLine("the value of a");

            }
            if (a != b) //relational
             {
                 Console.WriteLine("a is notequal to b");
             }
             else {
                 Console.WriteLine("a is  equal to b");
             }

             if (d || e) //logical
             {
                 Console.WriteLine("the condition is true");
             }

         

             Console.WriteLine("the sizeof int is" + sizeof(int));  //miscellaneous
             Console.WriteLine("the sizeof int is" + sizeof(Boolean));  //miscellaneous
            Console.ReadKey();




        }
    }
}
