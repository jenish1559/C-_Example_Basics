﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AUDExmp
{
    public class Program
    {
       

        public void Add()
        {
            List<Book> book = new List<Book>();
            book.Add(new Book() { BookId = 1, BookName = "c#", BookAuthor = "alix", BookPrice = 657.99 });
            book.Add(new Book() { BookId = 2, BookName = "c++", BookAuthor = "ron", BookPrice = 555.79 });
            book.Add(new Book() { BookId = 3, BookName = "java", BookAuthor = "joy", BookPrice = 879.89 });
            book.Add(new Book() { BookId = 4, BookName = "asp.net", BookAuthor = "sem", BookPrice = 754.59 });
            book.Add(new Book() { BookId = 5, BookName = "vb.net", BookAuthor = "rom", BookPrice = 567.99 });

            var add = (from s in book where s.BookId == 6 select s).Last();

            foreach (var i in add)
            {
                Console.WriteLine(i);
            }
        }
        public void Update()
        {
            
        }

        public void Delete()
        {

        }

        static void Main(string[] args)
        {
            Console.ReadKey();
        }
    }
}
