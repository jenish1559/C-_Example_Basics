﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayListExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arraylist1 = new ArrayList();
            arraylist1.Add(1);
            arraylist1.Add("two");
            arraylist1.Add(3);
            arraylist1.Add(4.6);
            arraylist1.Add(true);

           
                Console.WriteLine("\n");
            arraylist1.Remove(true);

            foreach (var al1 in arraylist1 )
            {
                Console.WriteLine("the array list value is :"+al1);

            }

            Console.WriteLine("\n");
            arraylist1.Insert(3, 100);
            foreach (var i in arraylist1)
            {
                Console.WriteLine("the new arraylist is  :" + i);
            }
            Console.WriteLine("\n");
            arraylist1.Reverse();
             foreach (var item1 in arraylist1 )
             {
                 Console.WriteLine("the reverse value is : "+item1 );
             }
             Console.WriteLine("\n");
             Console.WriteLine("the count values :" + arraylist1.Count);

             Console.WriteLine("\n");
             ArrayList al2 = new ArrayList();
             al2.Add(33);
             al2.Add(22);
             al2.Add(55);
             al2.Add(11);
             al2.Add(44);

            al2.Sort();
           
            foreach (var item2 in al2 )
            {
                Console.WriteLine("the ascending value is : "+item2 );
            }

            Console.WriteLine("\n");
            Console.WriteLine("the count values :"+al2 .Count );
            Console.ReadKey();
        }
    }
}
