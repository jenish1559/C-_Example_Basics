﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace callbyref
{
    public class Program
    {
        public void show(ref int val)
        {
            val *= val;
            Console.WriteLine("the value is : "+val);
        }
        static void Main(string[] args)
        {
            int val = 20;
            Program p1 = new Program();
            Console.WriteLine("the first value is : " + val);
             p1.show(ref val);   
            Console.WriteLine("the sec value is :" +val);
            Console.ReadKey();
        }
    }
}
