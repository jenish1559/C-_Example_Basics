﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForeachExample
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] a={"H","E","L","L","O"};

            foreach (string b in a )
            {
                Console.WriteLine("the msg is :"+b );
            }
            Console.ReadKey();
        }

    }
}
