﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhileLoopExmp
{
   public class Program
    {
        static void Main(string[] args)
        {
            int a = 1, sum=2;

            while (a<=10)
            {
                sum += a;
                Console.WriteLine("the value is :"+sum  );
                a ++;
            }
            Console.ReadKey();
        }
    }
}
