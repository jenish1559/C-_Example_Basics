﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyExample
{
   public  class Program
    {
        static void Main(string[] args)
        {
            Exmp example = new Exmp();
            example.Number = 10;
            Console.WriteLine(example .Number );
            Console.ReadKey();
        }
    }
}
