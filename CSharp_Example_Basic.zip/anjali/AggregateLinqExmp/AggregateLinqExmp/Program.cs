﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AggregateLinqExmp
{
    class Program
    {
        static void Main(string[] args)

        {
            List<int> number = new List<int>();

            number.Add(36);
            number.Add(76);
            number.Add(23);
            number.Add(18);
            number.Add(87);
            number.Add(44);
            number.Add(12);

            var maxnum = number.Max();

            Console.WriteLine(" MAX :the largest value is : " +maxnum);
            Console.WriteLine("\n");
            var minnum = number.Min();
            Console.WriteLine(" MIN :the minmum value is :" +minnum );

            Console.WriteLine("\n");
            var total = number.Sum();
            Console.WriteLine(" SUM :the sum of total number :"+total );

            Console.WriteLine("\n");
            List<Student> list1 = new List<Student>();

            list1.Add(new Student() { StudId = 1, StudName = "sem", Age = 16 });
            list1.Add(new Student() { StudId = 2, StudName = "jay", Age = 21 });
            list1.Add(new Student() { StudId = 3, StudName = "ram", Age = 16 });
            list1.Add(new Student() { StudId = 4, StudName = "roy", Age = 20 });
            list1.Add(new Student() { StudId = 5, StudName = "tej", Age = 15 });

            bool allstud = list1.All(a => a.Age >12 && a.Age <20);

            Console.WriteLine(" ALL:all the students are teenagers :" +allstud );
            Console.WriteLine("\n");

            bool anystud = list1.Any(a1 => a1.Age >12 && a1.Age <20);
            Console.WriteLine(" ANY: is Any Student TeenAger :"+anystud );

            Console.WriteLine("\n");

            var avgAge = list1.Average(s=>s.Age);

            Console.WriteLine(" AVERAGE :the average Age is : " + avgAge);

            Console.WriteLine("\n");

            var totalstud = list1.Count();

            Console.WriteLine(" COUNT :the total students are : "+totalstud );

            Console.WriteLine("\n");

            var adultstud = list1.Count(s1=> s1.Age >= 18);

            Console.WriteLine(" COUNT :the total adult students are : "+adultstud );
            Console.WriteLine("\n");

            var maxage = list1.Max(s2=>s2.Age );
            Console.WriteLine(" MAX :the older student is : "+maxage );
            Console.WriteLine("\n");

            var minage = list1.Min(s3 => s3.Age);
            Console.WriteLine(" MIN :the minmum age is  : " + minage );
            Console.WriteLine("\n");

            var sumage = list1.Sum(s4 => s4.Age);
            Console.WriteLine(" SUM :the sum of total age : "+sumage );

            Console.WriteLine("\n");

            List<int> intlist = new List<int>() { 11,34,56,26,22,77,81};
            List<string> strlist = new List<string>() {null ,"two","ram","four","joy","jon"};
            List<string> emptylist = new List<string>();

            Console.WriteLine("the first int element is  :"+intlist.First());

            Console.WriteLine("\n");

            var even = intlist.First(i => i % 2 == 0);
            Console.WriteLine("the first even int element is :"+even);
            Console.WriteLine("\n");

            Console.WriteLine("the first string element is : "+ strlist.First());
            Console.WriteLine("\n");
            //Console.WriteLine("the string is empty :" + emptylist.First());
            Console.WriteLine("\n");

            Console.WriteLine("the last int element is  :" + intlist.Last());

            Console.WriteLine("\n");

            var even2 = intlist.Last(i1 => i1 % 2 == 0);
            Console.WriteLine("the last even int element is :" + even2);
            Console.WriteLine("\n");

            Console.WriteLine("the last string element is : " + strlist.Last());

            Console.WriteLine("\n");

           // Console.WriteLine("the string is empty :" + emptylist.Last());
            Console.WriteLine("\n");

            List<int> intlist1 = new List<int>() { 11, 34, 56, 26, 33, 77, 37 };
            List<string> strlist1 = new List<string>() { null, "two", "ram", "four", "jon", "joy" };
            List<string> emptylist1 = new List<string>();

            Console.WriteLine("the firstordefult int element is  :" + intlist1.FirstOrDefault());

            Console.WriteLine("\n");

            var even1 = intlist1.FirstOrDefault(i => i % 2 == 0);
            Console.WriteLine("the firstordefult even int element is :" + even1);
            Console.WriteLine("\n");

            Console.WriteLine("the firstordefult string element is : " + strlist1.FirstOrDefault());
            Console.WriteLine("\n");
            Console.WriteLine("the defult string is empty :" + emptylist1.FirstOrDefault ());

            Console.WriteLine("\n");
            Console.WriteLine("the lastordefult int element is  :" + intlist1.LastOrDefault());

            Console.WriteLine("\n");

            var even3 = intlist1.LastOrDefault(i => i % 2 == 0);
            Console.WriteLine("the lastordefult even int element is :" + even3);
            Console.WriteLine("\n");

            Console.WriteLine("the lastordefult string element is : " + strlist1.LastOrDefault());
            Console.WriteLine("\n");
            Console.WriteLine("the defult string is empty :" + emptylist1.LastOrDefault());
            Console.ReadKey();
        }
    }
}
