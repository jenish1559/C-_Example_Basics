﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Program
    
    {
        int a;
        public Program()
        {
            a=10;
        }
        int b;
        public Program(int x)
        {
        b=x;    

        }

        static void Main(string[] args)
        {
            Program a1 = new Program();
            Program a2 = new Program(6);
            Console.WriteLine("the value is:"+a1.a );
            Console.WriteLine("the value is:" +a2.b);
            Console.ReadKey();
            
        }
    }
}
