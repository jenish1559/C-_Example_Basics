﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> dic1 = new Dictionary<int, string>();
            dic1.Add(1,"c");
            dic1.Add(2,"c++");
            dic1.Add(3,"c#");
            dic1.Add(4,"java");
            dic1.Add(5,"asp.net");

            foreach (var d1 in dic1)
            {
                Console.WriteLine("the dictionary value is :"+d1);
            }
            Console.WriteLine("\n");
            Console.WriteLine("the total values are :"+dic1 .Count );
            Console.WriteLine("\n");
            Console.WriteLine("the value of key 5 :"+dic1[5]);
            Console.WriteLine("\n");
            Console.WriteLine("the containkey 4 ?:"+dic1.ContainsKey(4));
            Console.WriteLine("\n");
            Console.WriteLine("the containkey 7 ?:" + dic1.ContainsKey(7));
            Console.WriteLine("\n");
            Console.WriteLine("remove the key 2 :" +dic1.Remove(2));
            Console.WriteLine("remove the key 6 :" + dic1.Remove(6));
            Console.WriteLine("\n");
            Console.WriteLine("the total values are :" + dic1.Count);
            Console.ReadKey();
        }
    }
}
