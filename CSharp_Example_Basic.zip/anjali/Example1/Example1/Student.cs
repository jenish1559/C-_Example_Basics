﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    public class Student
    {
       private int student_id ;
       private string student_name;
       private int result;


        public int Result1(int sub1,int sub2)
        {
            result = sub1 + sub2;
          // Console.WriteLine("the result is :"+result);
            return result;
        }

        public int Id
        {
            get { return student_id; }
            set { student_id = value; }
        }
        public string Name
        {
            get { return student_name; }
            set { student_name = value;}
            
        }
    }

    
}
