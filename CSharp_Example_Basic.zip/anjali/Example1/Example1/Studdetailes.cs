﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
   public class Studdetailes
    {
        int ret;

        public Studdetailes() 
            {
            Student student1 = new Student();
            student1.Id = 1;     
            student1.Name = "jay";
            ret = student1.Result1(60,50);
            
        }
    }
}
