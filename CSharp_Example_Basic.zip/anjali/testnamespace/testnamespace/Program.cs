﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testnamespace
{
  public  class Program
    {
       public int test;
        
        static void Main(string[] args)
        {
            testnamespace.test.test1 t1 = new testnamespace.test.test1();
            Console.WriteLine("this is a namespace class");
            Console.ReadKey();
        }
    }
}
