﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo3
{
  public  class cons
    {
    public   int id;
      public cons()
      {
          id = 1;
      }
      public cons(int i)
      {
          id = i;
      }
    }
}
