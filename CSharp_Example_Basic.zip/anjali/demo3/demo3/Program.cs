﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo3
{
   public class Program
    {
       public void show(int val)
       {
           val += val;
           Console.WriteLine(" the function value is :" +val );

       }

       public void show(ref string m1)
       {
           Console.WriteLine("the messages is :"+m1);
       }
       
        static void Main(string[] args)
        {


            int a = 10;
            int b = 20;
            int d;
            int val = 50;
            string m1 ="Hello ";

            demo3.test2.test t2 = new demo3.test2.test(); //namespace
            cons c1 = new cons(); //defult cons
            cons c2 = new cons (10);  //pera cons
            Console.WriteLine("the value of c1 :"+c1.id);
            Console.WriteLine("the value of c2 :"+c2.id );

            d = a + b;
            Console.WriteLine("the value of addition is :"+d );
            
            d *= b;
            Console.WriteLine("the value is :" +d );

            b++;
            Console.WriteLine(" the new value of b :" +b);

            d = a ^ b;
            Console.WriteLine("the value of relational :" +d );
          
            
            Program f1 = new Program();
            Console.WriteLine("the function first value is : "+val);
            f1.show(val);
            Console.WriteLine("the function sec value is : "+val );

            Program m2 = new Program();
            Console.WriteLine("the msg :"+m1);
            m2.show(ref m1);
            Console.WriteLine("the new msg is :"+m1);
            Console.ReadKey();
        }
    }
}
