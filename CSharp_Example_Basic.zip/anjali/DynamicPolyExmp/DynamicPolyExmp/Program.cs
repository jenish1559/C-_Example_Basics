﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicPolyExmp
{
    public class Baseclass
    {
        public virtual void greeting()
        {
            Console.WriteLine("baseclass saying hello...");
        }
    }
    public class Subclass : Baseclass
    {
        public override void greeting()
        {
            base.greeting();
            Console.WriteLine("subclass saying hello...");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Subclass b1 = new Subclass();
            b1.greeting();
            Console.ReadKey();
        }
    }
}
