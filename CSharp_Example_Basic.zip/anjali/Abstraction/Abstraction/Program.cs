﻿using System;

namespace Abstraction
{
    abstract class shape
    {
        public abstract int area(); 
    }
     class rectangle : shape
    {
        private int length;
        private int width;

        public rectangle (int a =0 ,int b =0)
        {
            length = a;
            width = b;

        }
        public override int area()
        {
          
            return (length * width);
        }
    }
   public class Program
    {
        static void Main(string[] args)
        {
            rectangle r1 = new rectangle(20,15);
            r1.area();
          
            Console.WriteLine("area : "+r1.area ());
            
            Console.ReadKey();
        }
    }
}
