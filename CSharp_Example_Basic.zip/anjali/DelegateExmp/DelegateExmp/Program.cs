﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateExmp
{
  public  class Program
    {
      public delegate void delmethod();
      public class del
      {
          public void display()
          {
              Console.WriteLine("hello...");
          }
          public void show()
          {
              Console.WriteLine("hi....");
          }
          public void print()

          {
              Console.WriteLine("print ");
          }
      }
        static void Main(string[] args)
        {
            del d1 = new del();
            delmethod del1 = new delmethod(d1.show );
            delmethod del2 = new delmethod(d1.display );
            delmethod del3 = new delmethod(d1.print );

            del1();
            del2();
            del3();

            Console.ReadKey();


        }
    }
}
