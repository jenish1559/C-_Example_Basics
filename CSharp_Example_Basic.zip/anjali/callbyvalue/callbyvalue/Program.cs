﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace callbyvalue
{
  public  class Program
    {
      public void show(int val)
      {
          val *= val;
          Console.WriteLine("the value is : "+val);
      }
        static void Main(string[] args)
        {
            int val = 10;
            Program p1 = new Program();
            Console.WriteLine("the first value is :" + val );
            p1.show(val);
            Console.WriteLine("the seconde value is : "+val );
            Console.ReadKey();

        }
    }
}
