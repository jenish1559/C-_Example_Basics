﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListExmp3
{
  public class Program
    {
       
        static void Main(string[] args)
        {
            List<int> book_id = new List<int>();
            book_id.Add(1);
            book_id.Add(2);
            book_id.Add(3);
            book_id.Add(4);
            book_id.Add(5);
            foreach (int id1 in book_id)
            {
                Console.WriteLine("the int list is :"+id1);
            }
            Console.WriteLine("\n");

            book_id.Add(6);

           

            book_id[2]= 45;
            book_id.Remove(4);
          
            foreach (int id1 in book_id)
            {
                Console.WriteLine("the int list is :" + id1);
            }

            Console.WriteLine("\n");

            List<string> book_name = new List<string>();
            book_name.Add("c#");
            book_name.Add("c++");
            book_name.Add("java");
            book_name.Add("asp.net");
            book_name.Add("vb.net");
            book_name.Add("jquery");
            
           foreach (string name in book_name)
           {
               Console.WriteLine("the string list is :" +name);
           }
           Console.WriteLine("\n");

           var result = from s in book_name where s.Contains("j") select s;

           foreach (var a in result )
           {
               Console.WriteLine("the list is : "+a);
           }
           Console.WriteLine("\n");

            var result1 = from s1 in book_name where s1.StartsWith("a") select s1;

            foreach (var a1 in result1)
            {
                Console.WriteLine("the list is : " + a1);
            }
            Console.WriteLine("\n");

         

            /*
           int i = 0;
           do
            {
               Console.WriteLine("the string list is :" +book_name[i]);
               i++;
           } while (i < book_name.Count );

            
           int a = book_name.Count();

           for (int i = 0; i < a; i++)
           {
               Console.WriteLine("the string list is :" + book_name[i]);
           }
           */

            Console.WriteLine("\n");
           
            List<Book> book = new List<Book>();
            book.Add(new Book() { Id =1,Name ="c++" });
            book.Add(new Book() { Id =2,Name ="c#" });
            book.Add(new Book() { Id =3,Name ="java"});
            book.Add(new Book() { Id =4,Name ="asp.net"});
            book.Add(new Book() { Id =5,Name ="vb.net"});
         
           foreach (Book book1 in book)
            {
                Console.WriteLine(book1.Id+"  "+book1.Name);
            }
          
            Console.ReadKey();
     
        }
    }
}
