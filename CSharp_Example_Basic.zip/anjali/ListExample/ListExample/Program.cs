﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListExample
{
   public  class Program
    {
        static void Main(string[] args)
        {
            List<int> listnum = new List<int>();
            
                listnum.Add(11);
                listnum.Add(22);
                listnum.Add(33);
                listnum.Add(44);
                Console.WriteLine("\n");

            //int i1 = listnum.Find(i => i> 20);

              //  Console.WriteLine(i1);
                Console.WriteLine("\n");

                listnum.Reverse();
                listnum.Sort();
                foreach (int a in listnum)
                {
                    Console.WriteLine(a);

                }
         
                 Console.WriteLine("My Count" + listnum.Count);

                Console.WriteLine("\n");

                listnum.RemoveAt(2);
                foreach (int b in listnum)
                {
                    Console.WriteLine(b);
                }
                Console.WriteLine(listnum .Count );

                Console.WriteLine("\n");

                List<int> listnum1 = new List<int>();

                listnum1.Add(1);
                listnum1.Add(2);
                listnum1.Add(3);
                listnum1.Add(4);

                listnum1.Remove(3);
                listnum1.Insert(2,34);
                listnum1.Reverse();
                foreach (int a1 in listnum1)
                {
                    Console.WriteLine(a1);

                }

                Console.WriteLine("\n");

                listnum1.Clear();
                Console.WriteLine(listnum1.Count);

                Console.WriteLine("\n");

               
              

                List<string> listname = new List<string>();
                listname.Add("c");
                listname.Add("c++");
                listname.Add("c#");
                listname.Add("java");
                listname.Add("asp.net");
              
           
           foreach (string i in listname )
            {
                Console.WriteLine(i); 
            }
            Console.WriteLine("\n");

           int bs = listname.BinarySearch("c#");
           Console.WriteLine(bs);
           Console.WriteLine("\n");
            listname.TrimExcess();

           if (listname.Contains("j"))
           {
               Console.WriteLine("java was found");
           }
           else
           { 
               Console.WriteLine("java was not found"); 
           }
            Console.WriteLine(listname .Count );


            Console.ReadKey();
        }
    }
}
