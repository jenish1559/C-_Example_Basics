﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllConditionExmp
{
    class Program
    {
        static void Main(string[] args)
        {

            int a = 30;
            int c = 1, sum = 10;

        if(a<=10)
        {
            Console.WriteLine("a is less then equal to 10 : ");
        }
        else
        {
            Console.WriteLine("a is not less then equal to 10 :");
        }

        Console.WriteLine("the main value is :" + a);
      
            Console.WriteLine("\n");

        for (int b = 1; b < 10;b++ )
        {
            Console.WriteLine("the value is :"+b );
        }

        Console.WriteLine("\n");  
        while (c<=10)
        {
                sum *= c;
                Console.WriteLine("the multi value is :"+sum );
                c++;
        }
        Console.WriteLine("\n");

        do
        {
            sum += c;
            Console.WriteLine("the addition value is :"+sum );
            c++;
        } while (c <= 10);
        Console.WriteLine("\n");

        string val = "fri";
            
            switch (val )
            {
                case "mon":
                     Console.WriteLine("today is : Mon" );
                break;
                case "tue":
                     Console.WriteLine("today is : Tue");
                break;
                case "wed":
                     Console.WriteLine("today is : Wed");
                break;
                case "thu":
                     Console.WriteLine("today is : Thu");
                break;
                case "fri":
                     Console.WriteLine("today is : Fri");
                break;
                case "sat":
                     Console.WriteLine("today is : sat");
                break;
                case "sun":
                     Console.WriteLine("today is : Sun");
                break;
                default:
                     Console.WriteLine("not valid day");
                break;
            }

            Console.WriteLine("\n");
            int i = 11, j = 22;
            if (i>j)
            {
                Console.WriteLine("i is greater then j");
            }
            else if(i<j)
            {
                Console.WriteLine("i is less then j");
            }
            else
            {
                Console.WriteLine("i is not less then j");
            }

        Console.ReadKey();
        }
    }
}
