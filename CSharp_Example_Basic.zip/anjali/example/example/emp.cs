﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example
{
   public class Emp
    {
       public int empId;
       public Emp()
   {
       empId = 10;
   }
       public Emp(int x)
       {
           empId = x;
       }
    }
}
