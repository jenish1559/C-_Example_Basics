﻿using example.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example
{
   public  class Program
    {
        public void Show(int val)
        {
            val *= val;
            Console.WriteLine("the value is :"+val );
        }

       public void Show (ref int val2)
        {
            val2 += val2;
            Console.WriteLine("the value is : "+val2);
        }
        static void Main(string[] args)
        {
            int firstVal=11;
            int secVal =22;
            int totalVal;
            int val = 50;
            int val2 = 30;
             Test1 test1 = new Test1 ();



            Emp id2 = new Emp();
            Emp id3 = new Emp(20);
            Console.WriteLine("the value of emp id2 :"+id2.empId );
            Console.WriteLine("the value of emp id3 :"+id3.empId );

            totalVal = firstVal + secVal;
            Console.WriteLine("the value of c :" + totalVal);
            totalVal *= firstVal;
            Console.WriteLine("the value of c :" + totalVal);
            totalVal = firstVal ^ secVal;
            Console.WriteLine("the value of c :" + totalVal);
            firstVal++;
            Console.WriteLine("the value of a :" + firstVal);
            secVal--;
            Console.WriteLine("the value of b ;" + secVal);
            Console.WriteLine("the sizeof int is :"+sizeof(int));

            Program p1 = new Program();
            Console.WriteLine("the first value is :"+val);
            p1.Show(val);
            p1.Show(ref val2);
            Console.WriteLine("the sec value is :"+val);
            Console.ReadKey();            
        }
    }
}
