﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfExample
{
    public class Program
    {
        static void Main(string[] args)
        {
            int i = 50;

            if (i>=10)
            {
                Console.WriteLine("the i is less then equale to 10");
            }
            else
            {
                Console.WriteLine("the i is not less then equale to 10");
            }
            Console.WriteLine("the main value of i is :"+ i);
            Console.ReadKey();
        }
    }
}
