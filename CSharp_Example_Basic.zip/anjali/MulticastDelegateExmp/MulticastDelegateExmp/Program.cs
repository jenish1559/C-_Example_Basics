﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegateExmp
{
    class Program
    {
        public delegate void delmethod(int x,int y);

        public class Multidel
        {
            public void sumdel(int x,int y)
            {
                Console.WriteLine("the sum is :");
                Console.WriteLine(x + y);
            }
            public void subdel(int x,int y)
            {
                Console.WriteLine("the sub is :");
                Console.WriteLine(x - y);
            }

        }
        static void Main(string[] args)
        {
            Multidel md1 = new Multidel();
            delmethod del1 = new delmethod(md1.sumdel );
            del1 += new delmethod(md1.subdel );
            del1(80,40);
            Console.WriteLine("\n");
            del1 -= new delmethod(md1.sumdel );
            del1(40,20);

            Console.ReadLine();
        }
    }
}
