﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeastedIfExmp
{
   public class Program
    {
        static void Main(string[] args)
        {
            int totalMarks = 35;

            if(totalMarks >=80)
            {
                Console.WriteLine("you got higher then first class ");
            }
            else if(totalMarks >=60)
            {
                Console.WriteLine("you got first class");
            }
            else if (totalMarks >=40)
            {
                Console.WriteLine("you got pass class");
            }
            else
            {
                Console.WriteLine("you are failed");
            }
            Console.ReadKey();
        }
    }
}
