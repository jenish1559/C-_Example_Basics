﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchExmp
{
    class Program
    {
        static void Main(string[] args)
        {
            int value =3;
            int a = 5, b = 5, total;
            switch (value)
            {
                case 1:
                     total = a + b;
                     Console.WriteLine("the sum is :"+total );
                break;

                case 2:
                    total = a - b;
                    Console.WriteLine("the sub is:"+total );
                break;

                case 3:
                     total = a * b;
                     Console.WriteLine("the multi is :"+total );
                break;

                case 4:
                     total = a / b;
                     Console.WriteLine("the div is :"+total );
                break;

                default :
                   Console.WriteLine("not valid case number");
                break;

            }
            Console.ReadKey();
        }
    }
}
